//腾讯云
const qcloud = require('../../vendor/wafer2-client-sdk/index.js');
const config = require('../../config.js');
var app = getApp();
// client/pages/comment-view/comment-view.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: 0,
    img: "",
    title: "",
    comment_value: "",
    type: "text",
    userInfo: null,
    isLogin: "false",
  },
  /**
   * 发布影评
   */

  /**
   * 发布评论
   */
  addComment(e) {
    let content = this.data.comment_value;
    if (!content) return;
    console.log(this.data.id);
    console.log(this.data.comment_value);
    console.log(this.data.type);

    wx.showLoading({
      title: '正在发布评论',
    });

  
    qcloud.request({
      url: config.service.addComment,
      login: true,
      method: 'PUT',
      data: {
        content: this.data.comment_value,
        id: this.data.id,
        type: this.data.type
      },

      success: res => {
        wx.hideLoading();
        let data = res.data
        console.log(data)
        if (!data.code) {
          wx.showToast({
            title: '发表评论成功'
          })
          setTimeout(() => {
            wx.navigateBack()
          }, 1500)
        } else {
          console.log(res)
          wx.showToast({
            icon: 'none',
            title: '发表评论失败'
          })
        }
      },

      fail: res => {
        console.log("外部失败"+res)
        wx.hideLoading()
        wx.showToast({
          icon: 'none',
          title: '发表评论失败'
        })
      }


    });
  },

  /**
   * 重新编辑
   */
  redit(){
    wx.navigateBack({
      
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      id: options.id,
      img: options.img,
      title: options.title,
      comment_value: options.content,
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let self = this
    // console.log(app)
    app.checkSession({
      success: userInfo => {
        console.log(self)
        this.setData({
          userInfo,
          isLogin: true
        })
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '会话超期',
          image: '../../img-mini/error.svg'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})