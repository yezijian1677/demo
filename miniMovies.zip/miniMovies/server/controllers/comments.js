const DB = require("../utils/db.js");

module.exports = {

  /**
   * 添加评论
   */
  add: async ctx => {
    let user = ctx.state.$wxInfo.userinfo.openId
    let username = ctx.state.$wxInfo.userinfo.nickName
    let avatar = ctx.state.$wxInfo.userinfo.avatarUrl

    let id = +ctx.request.body.id
    let content = ctx.request.body.content || null
    let type = ctx.request.body.type

    if (!isNaN(movieId)) {
      await DB.query('INSERT INTO movies_comment(user, username, useravatar, content, id, type) VALUES (?, ?, ?, ?, ?, ?)', [user, username, avatar, content, movieId, type])
    }

    ctx.state.data = {}
  },
  

}